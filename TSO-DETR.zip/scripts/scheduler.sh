#!/bin/bash
exp_name=$1
proj_root="/path/to/project/workdir" # mod this

log_path_prefix="$proj_root/records/$exp_name"
work_dir_prefix="$proj_root/workplaces/$exp_name"

mkdir -p "$log_path_prefix"  # Create the log directory
mkdir -p "$work_dir_prefix"  # Create the work directory

script_prefix="$proj_root/configs"
script="$script_prefix/$exp_name.py"

set_seed="--seed 3407 --deterministic"
interpreter="/path/to/python/interpreter" # mod this
trainer_py="/path/to/mmdSTTL/tools/train.py" # mod this

num_runs=1
for ((run=1; run<=$num_runs; run++)); do
    log_file="$log_path_prefix/run_$run.log"
    work_dir="$work_dir_prefix/run_$run"

    # Clear work-dir if it exists
    if [ -d "$work_dir" ]; then
        rm -rf "$work_dir"
    fi

    > "$log_file"  # Clear the log file or create an empty file

    echo "开始第 $run 次训练, 详细记录文件保存在："
    echo "$log_file"
    echo "工作目录："
    echo "$work_dir"

    # Execute the training command and redirect output to the log file
    $interpreter $trainer_py $script --work-dir "$work_dir" $set_seed >> "$log_file" 2>&1
    
    # Check if the previous training run was successful
    if [ $? -eq 0 ]; then
        echo "第 $run 次成功" >> "$log_file"
    else
        echo "第 $run 次失败" >> "$log_file"
    fi
done