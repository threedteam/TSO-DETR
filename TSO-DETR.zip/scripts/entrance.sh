#!/bin/bash

# 根目录路径
rootpath="/path/to/configs"

# 定义文件名列表
filenames=(
    # "cascade_rcnn.py"
    # "faster_rcnn.py"
    "detr.py"
    # "defromable_detr.py"
)

# 循环遍历文件名列表
for filename in "${filenames[@]}"
do
    # 构建完整的文件路径
    filepath="$rootpath/$filename"

    # 使用basename命令截取文件名部分
    basename=$(basename "$filename" .py)

    # 输出文件名
    echo "执行任务: $basename"
    ./scheduler.sh "$basename"
done