# TSO-DETR: A Network for Small Object Detection of Cervical Cells in TCT Smear

This is the official implementation of our paper [TSO-DETR: A Network for Small Object Detection of Cervical Cells in TCT Smear](https://s3.amazonaws.com/edas.manuscripts/paper/1570987560.pdf?response-content-disposition=attachment%3B%20filename%3D1570987560%20paper.pdf&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAIKF6M6OQNJB3J62Q%2F20240505%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20240505T072802Z&X-Amz-SignedHeaders=host&X-Amz-Expires=86400&X-Amz-Signature=9062b7ee69eb64692567c5bb1a40a29371c3e8c5040c9e6845e5acf94bcabc41) on International Joint Conference on Neural (IJCNN).

This paper focuses on the problem of small object detection in cervical cell detection on TCT smear. Firstly, a method of DA and TSB was proposed to expand the number of small objects, and the classes of the dataset were balanced. Then a new model, TSO-DETR, was proposed for detecting small objects in cervical cells. This model combines PVTv2 and Deformable DETR, which can fuse multi-scale features.

<!-- 插入图片 -->
<div align="center">
  <img src="src/第4页-4.PNG" alt="图片描述">
  <p style="text-align: center;">TSO-DETR Arch</p>
</div>

<div align="center">
  <img src="src/第5页-6.PNG" alt="图片描述">
  <p style="text-align: center;">Presented channel mapper</p>
</div>

<div align="center">
  <img src="src/第5页-5.PNG" alt="图片描述">
  <p style="text-align: center;">Presented PLVP block</p>
</div>

## Usage

<!-- For a typical model, this section should contain the commands for training and testing. You are also suggested to dump your environment specification to env.yml by `conda env export > env.yml`. -->

- Prepare a conda environment with Python 3.7 and the following packages:

  ```
  python=3.7.12
  pytorch=1.10.0
  mmdetection=2.24.0
  ```

- Clone this repository:

  ```bash
  git clone https://github.com/0x6f6f/TSO-DETR.git
  cd TSO-DETR
  ```

- :warning: Override files in `mmdet\necks` to the mmdetection path to enable our modification to the original code.

  ```
  cd mmdet/necks
  cp -r ../../TSO-DETR/mmdet/necks/ .
  ```

- modify dataset path
  
  if you are using vscode, just search globaly with `#mod this` and replace them with your own path.

### Training commands

In MMDetection's root directory, run the following command to train the model:

```bash
python tools/train.py configs/TSO-DETR.py
```

For multi-gpu training, run:

```bash
python -m torch.distributed.launch --nnodes=1 --node_rank=0 --nproc_per_node=${NUM_GPUS} --master_port=29506 --master_addr="127.0.0.1" tools/train.py configs/TSO-DETR.py
```

## Results

<div align="center">

| Method         | mAP  | mAR  | Training time (min) | Inference time(s) |
|----------------|------|------|---------------------|-------------------|
| SSD            | 10.2 | 23.7 | 13.50               | 14.08             |
| YOLOX          | 11.9 | 30.1 | **4.60**                | **4.32**              |
| Faster R-CNN   | 13.4 | 32.5 | 5.70                | 6.69              |
| Cascade R-CNN  | 15.8 | 34.9 | 7.75                | 7.45              |
| RetinaNet      | 13.1 | 37.0 | 7.85                | 8.12              |
| Deformable DETR| 13.6 | 39.9 | 8.65                | 6.27              |
| SAM-DETR       | 16.8 | 38.3 | 7.90                | 3.26              |
| TSO-DETR(ours) | **24.8** | **50.5** | 17.40               | 8.32              |

</div>



## Citation

<!-- You may remove this section if not applicable. -->

```latex
@article{Chen_2024,
   title={TSO-DETR: A Network for Small Object Detection of Cervical Cells in TCT Smear},
   journal={International Joint Conference on Neural},
   publisher={Institute of Electrical and Electronics Engineers (IEEE)},
   author={Xin Chen, Lin Yi, Li Liu, Di Lv, Ziheng Liu, Ran Liu.},
   year={2024},
   month={Mar},
}
```

## Acknowledgement

<!-- You may remove this section if not applicable. -->

This project is based on [MMDetection](https://github.com/open-mmlab/mmdetection).

## License

This project is released under the [Apache 2.0 license](LICENSE).